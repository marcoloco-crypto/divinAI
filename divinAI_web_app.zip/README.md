# divinAI

**Cyberpunk Oracle Web App**  
Welcome to `divinAI`, your AI-powered portal into digital divination. Guided by Miss Kleo, a futuristic oracle, explore tools like:

- 🔮 Magic 8-Ball
- 🍪 Fortune Cookie
- 🧬 AI-driven astrology (coming soon!)
- 💡 Cyber scrying and more...

This is an open-source educational project blending science fiction, art, and mysticism.

## 🚀 Live Preview
Will be available soon via GitHub Pages.

## 🛠️ Setup
Upload files to GitHub, enable GitHub Pages from Settings → Pages → `main` branch → `/ (root)`.

## 📖 License
[MIT License](LICENSE)

Made with ❤️ and ✨ by the divinAI team.
